export interface APIKey {
  id: string;
  user_id: string;
  key_type: string;
  key_value: string;
  created_at: string;
}